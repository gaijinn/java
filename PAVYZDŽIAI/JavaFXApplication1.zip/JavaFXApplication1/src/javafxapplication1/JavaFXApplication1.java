/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication1;

import com.sun.webkit.dom.EventImpl;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author Marius
 */
public class JavaFXApplication1 extends Application {
    
    
    private String theme1Url = getClass().getResource("theme1.css").toExternalForm();
    private String theme2Url = getClass().getResource("theme2.css").toExternalForm();
    
    
    @Override
    public void start(Stage stage) throws Exception {
       
        
      Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));

 
        Scene scene = new Scene(root);
       
        
        final EventHandler keyF1 = new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                
                if(event.getCode() == KeyCode.F1)
                {
                  //  JOptionPane.showMessageDialog(null, "F1 klavisas paspaustas");
                       scene.getStylesheets().remove(theme2Url);
                     scene.getStylesheets().add(theme1Url);       
                }
                else if(event.getCode() == KeyCode.F2){
                    scene.getStylesheets().remove(theme1Url);
                   scene.getStylesheets().add(theme2Url);       
                }//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };
        
        scene.setOnKeyPressed(keyF1);
        
        
        
        
        
        
        
        
        stage.setScene(scene);
        stage.show();
          
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
