/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication1;

import java.awt.MouseInfo;
import java.awt.Point;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;

import javafx.fxml.Initializable;

import javafx.scene.canvas.GraphicsContext;

import javafx.scene.effect.DropShadow;

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

import javax.swing.JOptionPane;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.CubicCurveTo;
import javafx.scene.shape.HLineTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.VLineTo;
import javafx.util.Duration;

/**
 *
 * @author Marius
 */
public class FXMLDocumentController implements Initializable {

    private GraphicsContext gc;

    private static int countPoints = 0;

    ObservableList<PieChart.Data> pieChartData
            = FXCollections.observableArrayList(
                    new PieChart.Data("Grapefruit", 13),
                    new PieChart.Data("Oranges", 25),
                    new PieChart.Data("Plums", 10),
                    new PieChart.Data("Pears", 22),
                    new PieChart.Data("Apples", 30));

    @FXML
    private AnchorPane langas;
    
    @FXML
    private Button button;

    @FXML
    private Canvas canvas;

    @FXML
    private Rectangle daugiakampis;

    @FXML
    private PieChart diagrama;

    @FXML
    private TextField valuePieChart;

    @FXML
    private ColorPicker spalva;

    @FXML
    private TextField namePiechart;

    @FXML
    private ComboBox<String> stilius;

    @FXML
    private Label label;

    @FXML
    private void handleButtonAction(ActionEvent event) {

        final Rectangle rectPath = new Rectangle(0, 0, 40, 40);
        rectPath.setArcHeight(10);
        rectPath.setArcWidth(10);
        rectPath.setFill(Color.ORANGE);

        gc = canvas.getGraphicsContext2D();
        gc.setFill(Color.LIME);
        gc.fillRect(rectPath.getX(), rectPath.getY(), rectPath.getWidth(), rectPath.getHeight());

        Path path = new Path();

        path.getElements().add(new MoveTo(560.0f, 0.0f));
        path.getElements().add(new LineTo(100.0f, 100.0f));

        PathTransition pathTransition = new PathTransition();
        pathTransition.setDuration(Duration.millis(3000));
        pathTransition.setPath(path);
        pathTransition.setNode(canvas);
        pathTransition.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pathTransition.setCycleCount(Timeline.INDEFINITE);
        pathTransition.setAutoReverse(true);
        pathTransition.play();

        pieChartData.add(new PieChart.Data(namePiechart.getText(), Double.parseDouble(valuePieChart.getText())));

        diagrama.setData(pieChartData);

        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        spalva.setOnAction(e->{
            daugiakampis.setFill(spalva.getValue());
        });
       
        
        
        
        stilius.getItems().removeAll(stilius.getItems());
        stilius.getItems().addAll("Option A", "Option B", "Option C");
        stilius.getSelectionModel().select("Option B"); 
    }

}
