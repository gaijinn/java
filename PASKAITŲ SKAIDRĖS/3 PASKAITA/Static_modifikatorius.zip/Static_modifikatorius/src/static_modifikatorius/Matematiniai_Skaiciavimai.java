/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package static_modifikatorius;

/**
 *
 * @author Marius
 */
import static java.lang.Math.sqrt;
import static java.lang.System.out;

public class Matematiniai_Skaiciavimai {
    
    void spausdintiTeksta(String tekstas){
        out.println("Mano Tekstas: "+ tekstas);
    }
    void saknis(){
        sqrt(16);
    }
    
    
}



